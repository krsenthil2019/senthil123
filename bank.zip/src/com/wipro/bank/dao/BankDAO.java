package com.wipro.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.util.DBUtil;

public class BankDAO {
	Connection conn;
		public int generateSequenceNumber()
	{
		conn=DBUtil.getDBConnection();
		int i = 0;
		ResultSet rs;
		try {
			PreparedStatement pst = conn.prepareStatement("select transactionId_seq.NEXTVAL from dual ");
			 rs=pst.executeQuery();
			 rs.next();
			 i=rs.getInt(1);
				} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public boolean validateAccount(String accountNumber) 
	{		
		conn=DBUtil.getDBConnection();
			boolean stat=false;
				if(conn!=null)
				{
					try {
						PreparedStatement pst=conn.prepareStatement("select account_number from account_tbl");
						 ResultSet rss=pst.executeQuery();
				          while(rss.next())
				 		 {
				 					    	if(rss.getString(1).equals(accountNumber))
				 			 {
				 				
				 					    		stat=true;
				 			}
				 			   	
				 		} 
					    
					}
	catch (SQLException e) {
		e.printStackTrace();
	}
				
		}
		
	return stat;
		}
	public float findBalance(String accountNumber)
	{
		float st = 0;
		{
			conn=DBUtil.getDBConnection();
		
			if(conn!=null){
															
					try {
						PreparedStatement pstm = conn.prepareStatement("select *from ACCOUNT_TBL where Account_Number="+accountNumber);
						ResultSet rslt = pstm.executeQuery();	
						while(rslt.next())
						 {
									    	if(rslt.getString(1).equals(accountNumber))
							 			    st=rslt.getFloat(3);
									    else
									    	st=-1;
									    						 
						 }
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		return st;

	}
	public boolean transferMoney(TransferBean transferBean)
	{
		conn=DBUtil.getDBConnection();
		if(conn!=null){
			try{
				PreparedStatement pstm = conn.prepareStatement("insert into TRANSFER_TBL values(?,?,?,?,?)");
				pstm.setInt(1,generateSequenceNumber());
				pstm.setString(2,transferBean.getFromAccountNumber());
				pstm.setString(3,transferBean.getToAccountNumber());
				pstm.setDate(4, new java.sql.Date(new Date().getTime()));
				pstm.setFloat(5,transferBean.getAmount());
				if(pstm.executeUpdate()==1){
					return true;
				}
				else
					return false;
			}catch(Exception e){}
		}		
		return false;
	}
	public boolean updateBalance(String accountNumber, float newBalance)
	{
		conn=DBUtil.getDBConnection();
		try{
			PreparedStatement pstm = conn.prepareStatement("update account_tbl set balance=? where account_number=?");
			pstm.setFloat(1,newBalance);
			pstm.setString(2,accountNumber);
			if(pstm.executeUpdate()==1)
				return true;
		}catch(Exception e){
			
		}
		return false;
	}	

	}

