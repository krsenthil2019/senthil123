package com.wipro.bank.service;
import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.dao.BankDAO;
import com.wipro.bank.util.InsufficientFundsException;

public class BankMain {
			public static void main(String[] args) {
						// View Balance
				BankMain bankMain=new BankMain();
		System.out.println(bankMain.checkBalance("1234567890"));
		 // TransferMoney
		TransferBean transferBean = new TransferBean();
		transferBean.setFromAccountNumber("1234567890");
		transferBean.setAmount(500);
		transferBean.setToAccountNumber("1234567891");
		transferBean.setDateOfTransaction(new java.util.Date());
		 System.out.println(bankMain.transfer(transferBean));
	}

	public String checkBalance(String accountNumber)
	{
		BankDAO b=new BankDAO();
		String str="";
		boolean validate;
		System.out.println(accountNumber);
					validate=b.validateAccount(accountNumber);
			if(validate)
					{
						float balance=new BankDAO().findBalance(accountNumber);
								str="BALANCEIS:"+balance;
					}
			else
				str="ACCOUNT NUMBER invalid";
			
		return str;
	}

	@SuppressWarnings("unused")
	public String transfer(TransferBean transferBean)
	{
		/*BankDAO b=new BankDAO();
		TransferBean t=new TransferBean();
		boolean b1;
		String str = null;
		//b1=(b.validateAccount(t.getFromAccountNumber()))&&(b.validateAccount(t.getToAccountNumber()));
		if(transferBean!=null)
			    if((b.validateAccount(t.getFromAccountNumber()))&&(b.validateAccount(t.getToAccountNumber())))
	    		if(b.findBalance(t.getFromAccountNumber())>=t.getAmount())
				if(b.updateBalance(t.getFromAccountNumber(),b.findBalance(t.getFromAccountNumber())-t.getAmount()))
				if(b.updateBalance(t.getToAccountNumber(), b.findBalance(t.getToAccountNumber())+t.getAmount()))  
                str="SUCCESS";
				else
					try {
						throw new InsufficientFundsException();
					} catch (InsufficientFundsException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				else try {
					throw new InsufficientFundsException();
				} catch (InsufficientFundsException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				else str="Invalid Account";
	    		else str="Invalid";
		return str;*/
		String fromAccountNumber=transferBean.getFromAccountNumber();
		String toAccountNumber=transferBean.getToAccountNumber();
		float amount=transferBean.getAmount();
		BankDAO bankDAO=new BankDAO();
		if(transferBean!=null)
			if(bankDAO.validateAccount(fromAccountNumber)&&bankDAO.validateAccount(toAccountNumber)){
				try{
					if(bankDAO.findBalance(fromAccountNumber)>=amount){
						if(bankDAO.transferMoney(transferBean))
							if(bankDAO.updateBalance(fromAccountNumber, bankDAO.findBalance(fromAccountNumber)-amount))
								if(bankDAO.updateBalance(toAccountNumber, bankDAO.findBalance(toAccountNumber)+amount))  
									return "SUCCESS";
						return "FAIL";
					}
					else
						throw new InsufficientFundsException();					
				}catch(InsufficientFundsException e){
					return "INSUFFICIENT FUNDS";
				}
			}
			else				
				return "INIVALID ACCOUNT";
		else
			return "FAIL";
	}

					}

