package com.wipro.bank.util;

import java.sql.Connection;

import java.sql.DriverManager;

public class DBUtil {
	public static Connection getDBConnection()
	{
		Connection con=null;
		if(con==null)
		{
		try {
			   Class.forName("oracle.jdbc.driver.OracleDriver");
		           con=DriverManager.getConnection("Jdbc:Oracle:thin:@localhost:1521:xe","system","manager");
		           		}
			catch(Exception e) {
			    System.out.println(e);
			}
						}
		return con;
		
	}
}