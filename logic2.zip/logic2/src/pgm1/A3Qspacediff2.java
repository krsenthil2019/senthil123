package pgm1;
import java.io.*;
import java.util.*;
public class A3Qspacediff2 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input1="1999bangalore";
		String res="";
		int temp=0,n=0;
		int len=input1.length();
		for(int i=0;i<len-1;i++)
		{
		
			if(Character.isLetter(input1.charAt(i)))
			{
				res=res+input1.charAt(i);
				temp=Math.abs(((int)input1.charAt(i)-96)+((int)input1.charAt(i+1)-96));
				if(temp>26)
				{
				int sum=temp%26;
				if(sum!=0)
				{
				char ch=(char) (sum+96);
				res=res+ch;
				}
				else
				{
					char ch='o';
					res=res+ch;	
				}
				}	
				else 
				{
					char ch=(char) (temp+96);
					res=res+ch;
				}
				}
				
			else
			{
				res=res+input1.charAt(i);
			}
			
		
		}
		System.out.println(res+input1.charAt(len-1));
				
	}

}
