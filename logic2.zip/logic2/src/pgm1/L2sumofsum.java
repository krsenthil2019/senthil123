package pgm1;
/*Verified*/
public class L2sumofsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input1=582109; /*op:(5+8+2+1+0+9)+(8+2+1+0+9)....=85*/
		int i=0,j=0,res=0;
		String s=String.valueOf(input1);
		while(j<s.length())
		{
		for( i=j;i<s.length();i++)
		{
			res=res+Character.getNumericValue(s.charAt(i));
		
		}
		
		System.out.println(res+"new");
j=j+1;
		}
		System.out.println(res);
	}

}
