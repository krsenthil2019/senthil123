package pgm1;

public class L2sumofdiff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1;
		int b = 2;
		int N = 6;
		int result = N;
		if (a == 1) {
			for (int i=1; i<N; i++) {
				result = result - (N - i) + (N - (i + 1));
				N--;
			}
		} else {
			for (int i=1; i<N; i++) {
				result = result + (N - i) - (N - (i + 1));
				N--;
			}
		}

		System.out.println(result);
	}

}
