package pgm1;
import java.io.*;
import java.util.*;
import java.lang.*;
public class L3poli {
/*remove one digit to make polindrome*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=2332;
String temp="";
String s=String.valueOf(a);
int flag=0;
char c='q';
StringBuilder ssb=new StringBuilder(s);
String v=ssb.reverse().toString();
if(s.equals(v))
{
	System.out.println("its already polindrome");
}
else
{
for(int i=0;i<s.length();i++)
{
	StringBuilder rev=new StringBuilder(s);
	 temp=rev.deleteCharAt(i).toString();
	 StringBuilder sb=new StringBuilder(temp);
	String r=sb.reverse().toString();
	if(temp.equals(r))
	{
		c=s.charAt(i);
		break;
	}
temp=s;
}
}


}
	
}
/*----------------------------------------*/
/*int a=input1;
int res=0;
String temp="";
String s=String.valueOf(a);
char c;
StringBuilder ssb=new StringBuilder(s);
String v=ssb.reverse().toString();
if(s.equals(v))
{
res=-1;
}
else
{
for(int i=0;i<s.length();i++)
{
StringBuilder rev=new StringBuilder(s);
 temp=rev.deleteCharAt(i).toString();
 StringBuilder sb=new StringBuilder(temp);
String r=sb.reverse().toString();
if(temp.equals(r))
{
	c=s.charAt(i);
	res=Character.getNumericValue(c);
	break;
}
temp=s;
}
}

return res;	*/