package pgm1;

public class L3unstable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] stable=new int[5];
		int[] unstable=new int[5];
		int[] array={12889};
		
		int flag=0,flag1=0,n=0,m=0,temp=0,rem=0,pswd=0,sum=0;
	
		for(int i=0;i<5;i++)
		{
				int[] dig_arr={0,0,0,0,0,0,0,0,0,0};
			temp=array[i];
			do{
			    rem=temp%10;
				dig_arr[rem]++;
				temp/=10;
			}while(temp>0);
			
				for(int j=0;j<10;j++)
			    {
				if(dig_arr[j]!=0)
				{
					flag=dig_arr[j];
					break;
				}
				}
				
			for(int k=0;k<10;k++)
			{
				if(flag==dig_arr[k] || dig_arr[k]==0)
				{
						flag1=1;
				}
				else
				{	flag1=0;
				    break;
				}
				
			}
			if(flag1==1)
			{
				stable[m]=array[i];
				m++;
			}
			else
			{
				unstable[n]=array[i];
				n++;
			}
			
		}
	
		for(int x=0;x<n;x++)
		{
			sum=sum+unstable[x];
			//System.out.println("UNstable Sum:"+unstable[x]);
		}
		pswd=sum;
		System.out.println("Password:"+pswd);
		//return pswd;

	}



	

}

