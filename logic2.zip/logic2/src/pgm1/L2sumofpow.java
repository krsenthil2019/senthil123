package pgm1; /*Verified*/
import java.util.*;
import java.lang.*;
import java.math.*;
public class L2sumofpow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int input1=582109; /*390693*/
		int num=0;
		String ip=String.valueOf(input1);
		for(int i=0;i<ip.length();i++)
		{
			for(int j=i+1;j>i;j--)
			{
				if(j<ip.length())
				{
			int l=Character.getNumericValue(ip.charAt(i));
			int k=Character.getNumericValue(ip.charAt(j));
			int pow=(int)Math.pow(l,k);
			num=num+pow;
				}
			else
			{
			int l=Character.getNumericValue(ip.charAt(i));
			int pow=(int)Math.pow(l,0);
			num=num+pow;
			}
			}
		}
		int gen=num;
		System.out.println(gen);
	}

}
