/*i/p: a=1,b=3,c=6 Nth pos=?
 * N=17
 *  * series : 1,3,6,8,11,13,16,18,21,23,26,28,31,33,36,38,41  * ans: 41
 * */

package pgm1;

public class L3nthpos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=1;int b=3;int c=6;int N=17;
int od=b-a;
int ed=c-b;
int[] num=new int[100];
num[0]=a;
num[1]=b;
num[2]=c;
for(int i=3;i<N;i++)
{
	if(i%2==0)
	{
		num[i]=num[i-1]+ed;
	}
	else 
	{
		num[i]=num[i-1]+od;
	}
}
System.out.println(num[N-1]);

	}

}
