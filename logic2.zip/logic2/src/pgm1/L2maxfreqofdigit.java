package pgm1;

public class L2maxfreqofdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Finding the most frequently occurring digits in a series of numbers*/
int[] input1= {231,3333,3453,66,9090,7};
int input2=6;

		int[] x={0,0,0,0,0,0,0,0,0,0};
		
		int index=0;
		for(int i=0;i<=input2-1;i++)
		{
			while(input1[i]!=0)
			{
			int a=input1[i]%10;
				x[a]=x[a]+1;
				input1[i]=input1[i]/10;
			}
					}
		int max=x[0];
		
		for(int j=1;j<10;j++)
		{
			if(x[j]>=max)
				{
					max=x[j];
					index=j;
				}
			}
		System.out.println(index);
	}

}
