package pgm1;

import java.io.*;
import  java.util.*;

// Read only region start
class L3robet
{

	public String moveRobot(int input1,int input2,String input3,String input4){
		// Read only region end
		// Write code here...
int x=Character.getNumericValue(input3.charAt(0));
int y=Character.getNumericValue(input3.charAt(2));
char direction=input3.charAt(4);
String str="";
for(int i=0;i<input4.length();i++)
{
	if(input4.charAt(i)=='L')
	{
		if(direction=='E')
direction='N';
		else if(direction=='N')
direction='W';
		else if(direction=='S')
direction='E';
		else if(direction=='W')
direction='S';
		else str="ER";
	}
	else if(input4.charAt(i)=='R')
	{
		if(direction=='E')
direction='S';
		else if(direction=='N')
direction='E';
		else if(direction=='S')
direction='W';
		else if(direction=='W')
direction='N';
		else str="ER";
	}
	else if(input4.charAt(i)=='M')
	{
		if(direction=='E')
		{
			x++;
			if(x>input1 || y>input2 || x<0 || y<0) 
{ x--; str="ER"; break; } 
		}
		else if(direction=='N')
		{
			y++;
			if(x>input1 || y>input2|| x<0 || y<0) 
{y--; str="ER"; break; } 
			
		}
		else if(direction=='S')
		{
			y--;
			if(x>input1 || y>input2|| x<0 || y<0) 
{y++; str="ER"; break; } 
			
		}
		else if(direction=='W')
		{
			x--;
			if(x>input1 || y>input2|| x<0 || y<0)
 { x++; str="ER"; break; } 
			
		}
	}
	
}
if(str=="ER") 
	str=x+"-"+y+"-"+direction+"-"+str;
else
	str=x+"-"+y+"-"+direction;
		return str;
        
		
	}
}


}
