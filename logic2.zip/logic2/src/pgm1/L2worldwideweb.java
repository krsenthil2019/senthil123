package pgm1;
import java.io.*;
import java.util.*;
import java.lang.*;
public class L2worldwideweb {
	
	int i,j,k,l,m,n=0;
	public static void main(String args[]) {
	String res="";
	String input="World Wide Web";
	input=input.toLowerCase();
	
	String[] str=input.split("\\s");
	for(String word:str)
		{
		res=res+String.valueOf(countf(word));
		
		}
	System.out.println(res);	
	}	
	
	
	public static int countf(String temp)	
		
	{
		int n=0;
		for(int i=0;i<temp.length()/2;i++)
		{
			int m = (temp.charAt(i) - 'a') - (temp.charAt(temp.length() - 1 - i) - 'a');
			n=n+Math.abs(m);			
		}
		
		if(temp.length()%2!=0)
		{
		   n =n+ temp.charAt(temp.length()/2) - 'a' + 1;
		  
		}
		
	return n;
	}
	}	
	