package pgm1;

public class decresingnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] input1= {12,3,4,13,23,10,9,34};
int input2=8;
int count=0;
int fre=0;
int max=0;
for(int j=0;j<input2-1;j++)
{
	if(input1[j]>input1[j+1])
	{
		count++;
		for(int k=j;k<input2-1;k++)
		{
			if(input1[k]>input1[k+1])
			{
				fre++;
				
			}
		}
	}
max=fre;
}
	}

}
