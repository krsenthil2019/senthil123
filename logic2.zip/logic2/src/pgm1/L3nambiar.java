package pgm1;

public class L3nambiar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String input1="9880127431";
int sum=0;
String str="";
	for(int i=0;i<input1.length();)
	{
		if(Character.getNumericValue(input1.charAt(i))%2==0)
		{
			do
			{
				if(i==input1.length())
					break;
				sum=sum+Character.getNumericValue(input1.charAt(i));
				i++;
			}while(sum%2==0);
				str=str+sum;									
		}
		else
		{
			do
			{
				if(i==input1.length())
					break;
				sum=sum+Character.getNumericValue(input1.charAt(i));
				i++;
			}while(sum%2==1);
			str=str+sum;
		}
		sum=0;
	}
sum=Integer.parseInt(str);
System.out.println(sum);
	}

}
