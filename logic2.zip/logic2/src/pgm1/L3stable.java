package pgm1;

class UserMainCode
{

    public int findPassword(int input1,int input2,int input3,int input4,int input5){
       int [] arr={input1,input2,input3,input4,input5};
     
        int[] sta=new int[5];
        int[] unsta=new int[5];
        boolean flag=false;
        int l=0;
        int ct1=0,ct2=0;
for(int i=0;i<arr.length;i++)
        {
            int[] dig={0,0,0,0,0,0,0,0,0,0};
            int j=arr[i];
            while(j>0)
            {
                dig[j%10]++;
                j=j/10;
            }
            
            int max=dig[0];
            
            for(int k=1;k<dig.length;k++)
            {
                if(max<dig[k])
                    max=dig[k];
            }
            
            for(l=0;l<dig.length;l++)
            {
                if(dig[l]==max||dig[l]==0)
                {    flag=true;
                continue;
                }
                else
                {flag=false;
                    break;}
            }
            
            if(flag)
                    sta[ct2++]=arr[i];
            else
                 unsta[ct1++]=arr[i];
        }
        int max1=unsta[0];
            for(int m=1;m<unsta.length;m++)
            {
                if(max1<unsta[m])
                    max1=unsta[m];
            }
            System.out.println(max1);
        int min1=sta[0];
            for(int n=1;n<sta.length;n++)
            {
                if(min1>sta[n]&&sta[n]!=0)
                    min1=sta[n];
            }
        int pass=max1-min1;
        System.out.println(min1);
        return pass;
    }
}
class L3stable {
    public static void main(String[] args)

    {
        UserMainCode s1=new UserMainCode();
        int s=s1.findPassword(12,1313,122,678,898);
        System.out.println(s);
}
}
