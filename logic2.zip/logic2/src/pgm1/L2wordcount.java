package pgm1;

public class L2wordcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*ip:web Technologies : op:3+12=15=1+5=6 (PIN: 6)*/
		String input1="Wipro Technologies";
		int res=0,temp=0,k=0;
		String[] val=input1.split("\\s");
		for(String word:val)
		{
res=res+word.length();
		}
		String r=String.valueOf(res);
		if(r.length()>1)
		{
			for(int i=0;i<r.length();i++)
			{
				k=Character.getNumericValue(r.charAt(i));
temp=temp+k;
			}
		}
		System.out.println(temp); 

	}

}
