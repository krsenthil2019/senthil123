package pgm1;
import java.io.*;
import  java.util.*;
import java.lang.*;
public class L2fiberfever { 

	public static void main(String[] args) {
		
		String input1="fi_er";
		String input2="fiber:fever:filer:felir";
		String E="ERROR-009";
		input1=input1.replace("_",".");
		String S=new String();
		String arr[]=input2.split(":");
		String result="";
		for(String temp:arr)
		{
			if(temp.toLowerCase().matches(input1.toLowerCase()))
			{
			S= S+temp.toUpperCase()+":";
				
		}
			
		}
		if(S.isEmpty())
		{
			System.out.println(E);  ;
		}
		else
		{
					
	result=S.substring(0, S.length()-1);
		}
System.out.println(result); 
			}
		}

	


