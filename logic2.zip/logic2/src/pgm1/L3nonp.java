package pgm1;

public class L3nonp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {10,20,30,40,50,60,70,80,90,100};
int l=10;
int num[]=new int[l];
int pos[]=new int[l];
int prime[]=new int[l];
//prime[0]=a[2];
int nprime[]=new int[l];
nprime[0]=a[0];
nprime[1]=a[1];
int m=1,n=2,i=0,j,k,psum=0,npsum=0;
int flag=0;
for(i=0;i<l;i++)
{
	num[i]=a[i];
	pos[i]=i;
}
for(j=2;j<l;j++)
{
	for(k=2;k<=j/2;k++)
	{
		if(j%k==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==0)
	{
		prime[m]=a[j];
		System.out.println(prime[m]);
		m++;
		
	}
	else
	{
		nprime[n]=a[j];
		//System.out.println(nprime[n]);
		n++;
		flag=0;
	}
	
}
for(int y=0;y<nprime.length;y++)
{
	
	npsum=npsum+nprime[y];
}
System.out.println(npsum);
	}

}
