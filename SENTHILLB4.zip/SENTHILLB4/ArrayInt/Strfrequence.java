package ArrayInt;

public class Strfrequence {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	 int i, j, k;
     String str;
     char c, ch;
    str="ProGRamming"; 
    str=str.toLowerCase();
    System.out.println(str);
     i=str.length();
     for(c='A'; c<='z'; c++)
     {
         k=0;
         for(j=0; j<i; j++)
         {
             ch = str.charAt(j);
             if(ch == c)
             {
                 k++;
             }
         }
         if(k>1)
         {
             System.out.println("The character " + c + " has occurred for " + k + " times");
         }
     }
}

}
