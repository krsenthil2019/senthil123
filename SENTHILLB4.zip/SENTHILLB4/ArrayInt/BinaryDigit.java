package ArrayInt;

public class BinaryDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a="0110";
String b="1011";
System.out.println(Integer.parseInt(a,2));
System.out.println(Integer.parseInt(b,2));
int x=Integer.parseInt(a,2)+Integer.parseInt(b,2);

System.out.println(Integer.toBinaryString(x));
	}

}
