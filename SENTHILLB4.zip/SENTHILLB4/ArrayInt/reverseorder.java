package ArrayInt;

public class reverseorder {
		public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] a={1,2,3,4,5,6};

for(int i:a)
{
	System.out.print(i);
	System.out.print(" ");
}
System.out.println("");
for(int i=a.length;i>0;i--)
{
	System.out.print(i);
	System.out.print(" ");
}
	}

}
