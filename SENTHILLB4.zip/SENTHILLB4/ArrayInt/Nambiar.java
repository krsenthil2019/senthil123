package ArrayInt;

public class Nambiar {

	public static int nnGenerator(String input1)
	
	{
		 	int i=0;
	        int n;
	        int sum;
	        StringBuilder sb=new StringBuilder();
	        while(i<10)
	        {
	            n=Character.getNumericValue(input1.charAt(i));
	            sum=n;
	        if(n%2!=0)
	        {
	        
	            for(int j=i+1;(sum%2!=0)&& j<10;j++)
	            {
	               
	             
	                 sum=sum+Character.getNumericValue(input1.charAt(j));
	                // System.out.println(sum+"i"+j);
	                 i=j;
	            }
	            sb.append(sum);
	            //System.out.println("final"+sb);
	        }
	      else
	        {

	           for(int j=i+1;(sum%2==0)&& j<10;j++)
	            {
	               
	             
	                 sum=sum+Character.getNumericValue(input1.charAt(j));
	                // System.out.println(sum+"i"+j);
	                 i=j;
	            }
	            sb.append(sum);
	            //System.out.println("final"+sb);
	       }
	        i++;
	        }
	        String s=sb.toString();
	        int res=Integer.parseInt(s);
	        //System.out.println(res);			
			
		return res;
	}


public static void main(String[] args) {
	// TODO Auto-generated method stub
System.out.println(nnGenerator("8123454210"));
}
}
