package ArrayInt;

public class Productandsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//The product of two numbers is 120 and the sum of their squares is 289. 
		//The number is ??? (x+y)2=x2+y2+2xy
		int xy=120;
		int sqxy=289;
		double z=sqxy+2*xy;
		System.out.print(Math.sqrt(z));
	}

}
