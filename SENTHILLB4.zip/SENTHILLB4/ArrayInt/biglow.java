package ArrayInt;

public class biglow {
public static void main(String args[])
{
	int[] a= {12,43,65,2,99,54,33};
int big=0,b=0,k=0;
for(int i=0;i<a.length;i++)
{
	if(big<a[i])
	{
		big=a[i];
	}
	
}
System.out.print(big);
for(int j=1;j<a.length;j++)
{
if(a[k]<a[j])
{
	b=a[k];
}
k++;
}

System.out.println("");
System.out.print(b);
}
}
