package ArrayInt;

public class Encryption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="board";
StringBuffer ss=new StringBuffer(s);
int i=0;
for(i=0;i<s.length()-1;i++)
{
	
	
	
	
	
	
	
	
	
	
	/*ss.append(s.charAt(i));
	//System.out.println(ss.charAt(i));
	//System.out.println(ss.charAt(i)-96);
	int d=(((ss.charAt(i)-96)+ss.charAt(i+1)-96)%26);
	System.out.println(d);
	System.out.println((char)d+96);
	ss.append((char)d+96);*/

}
System.out.println(ss);
	}

}
