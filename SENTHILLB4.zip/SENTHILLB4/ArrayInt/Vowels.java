package ArrayInt;

public class Vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="deepa";
s=s.toLowerCase();
char[] v=s.toCharArray();
int f = 0;
char[] vw= {'a','e','i','o','u'};

  for (int i = 0; i < s.length()-1; i++) 
    
    {
        for (int j = 0; j < 5; j++) 
        
        {
            if ((v[i] == vw[j]))
            {
            	for(int q=0;q<4;q++)
            	{
            		if ((v[i+1] == vw[q]))
            		{
                f++;
                break;
            		}
            	}
            }
        }
        if (f == 1) break; // Need to break out of loop again in case there are more than three consecutive vowels
    }
   
    if (f == 1) 
    {
        System.out.println("Consecutive Vowels Present");
    } else 
    {
        System.out.println("no Consecutive Vowels");
    }
	

	}
}
