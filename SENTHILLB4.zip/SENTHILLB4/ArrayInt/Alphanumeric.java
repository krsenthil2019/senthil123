package ArrayInt;

public class Alphanumeric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a="asd312V48";
char[] v=a.toCharArray();
for(char d:v)
{
	if(Character.isDigit(d)==true)
	{
		int y=Character.getNumericValue(d);
		System.out.println(y*y);
		System.out.println();
	}
	
}
	}

}
