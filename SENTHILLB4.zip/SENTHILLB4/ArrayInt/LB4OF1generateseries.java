package ArrayInt;

public class LB4OF1generateseries {
public static int series(int a,int b,int c,int d)
{
	int i,k=0,l=0,m=0;
	int[] s=new int[d];
	s[0]=a;
	s[1]=b;
	s[2]=c;
	
	if(s[0]<s[1])
	{
			
		k=s[1]-s[0];
		l=s[2]-s[1];
		
	}
	if(s[0]>s[1])
	{
		k=s[1]-s[0];
		l=s[2]-s[1];
		
	}
	
for(i=2;i<=d-1;i++)
{
	
	if(i%2!=0)
	{
		s[i]=s[i-1]+k;
		
		m=s[i];
	}
	else
	{
		s[i]=s[i-1]+l;
	
		m=s[i];
	}

}
return m;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

System.out.println(series(-1,-3,-6,100));
System.out.println(series(8,6,3,4));
	}

}
