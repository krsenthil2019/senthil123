package ArrayInt;

public class Aplphpos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ss="board are";
		ss=ss.toLowerCase();
		//s=s.replaceAll("\\s","");
		String[] se=ss.split("");
		String gh="";
		StringBuilder sb=new StringBuilder();
	for(String s:se)
	{
		for(int i=0;i<s.length()-1;i++)
		{
			sb.append(s.charAt(i));
			if(Character.isDigit(s.charAt(i)))
			{
				i++;
			}
			int k=s.charAt(i)-96;
			int l=s.charAt(i+1)-96;
			int m=k+l;
			if(m<26)
			{
				m=m+96;
				char g=(char)m;
				sb.append(g);
				//System.out.println(sb);
			}
			else if(m>26)
			{
				m=m%26;
				m=m+96;
				char g=(char)m;
				sb.append(g);
						}
			else
			{
				sb.append("0");
			}
		gh=sb.append(ss.charAt(ss.length()-1)).toString();
		}}
		StringBuilder sf=new StringBuilder();
	System.out.println(sf.append(gh));
		}
	}
		
	


