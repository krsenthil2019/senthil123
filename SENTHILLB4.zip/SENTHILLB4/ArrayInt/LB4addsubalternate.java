package ArrayInt;

public class LB4addsubalternate {
public static int addsub(int N,int opt)
{
	int i;
	int a=N;
	if(N>0&&N<=10000)
	{
		//System.out.println(p++);
	switch(opt)
	{
	case 1:
		for(i=1;i<a;i++)
		{
			if(a%2==0)
			{
				N=N-(a-i);
				a--;
			
				//System.out.println(p);
			}
			else
			{
				N=N+(a-i);
				a--;
				//System.out.println(p);
			}
		}
		
		break;
	case 2:
		for(i=1;i<a;i++)
		{
			if(a%2==0)
			{
				N=N+(a-i);
				a--;
			
				//System.out.println(p);
			}
			else
			{
				N=N-(a-i);
				a--;
				//System.out.println(p);
			}
		}
		
		break;	
		
	}}
	return N;
}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
System.out.println(addsub(6,1));
System.out.println(addsub(10000,2));
	}
}
