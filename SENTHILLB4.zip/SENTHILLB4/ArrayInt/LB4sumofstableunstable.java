package ArrayInt;

public class LB4sumofstableunstable {
	public static int stab(int a1,int a2,int a3,int a4,int a5)
	{
		int[] stable=new int[5];
		int[] unstable=new int[5];
		int[] array={a1,a2,a3,a4,a5};
		
		int flag=0,flag1=0,n=0,m=0,temp=0,rem=0,pswd=0,sum=0,sum1=0;
		for(int i=0;i<5;i++)
		{
			int[] dig_arr={0,0,0,0,0,0,0,0,0,0};
			temp=array[i];
			do{
			    rem=temp%10;
				dig_arr[rem]++;
				temp/=10;
			}while(temp>0);
			
				for(int j=0;j<10;j++)
			    {
				if(dig_arr[j]!=0)
				{
					flag=dig_arr[j];
					break;
				}
				}
			for(int k=0;k<10;k++)
			{
				if(flag==dig_arr[k] || dig_arr[k]==0)
				{
					flag1=1;
				}
				else
				{	flag1=0;
				    break;
				}
				
			}
			if(flag1==1)
			{
				stable[n]=array[i];
				n++;
			}
			else
			{
				unstable[m]=array[i];
				m++;
			}
		}
		for(int x=0;x<n;x++)
		{
			sum=sum+stable[x];
		}
		for(int x=0;x<m;x++)
		{
			sum1=sum1+unstable[x];
		}
		pswd=sum-sum1;
		return pswd;

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(stab(12332,121,34243,23411,10001));

	}
}
