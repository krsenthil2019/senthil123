package ArrayInt;
//pass=last letter of smaller name+entire word of larger name+Nth position of number(L-R)+Nth position of number(R-L)
//ip: Rajiv,Roy,560037,6 : op:yRavji75->YrAJIV75
public class password {
public static String pass(String a,String b,int c,int d)
{
	
	String s="";
	StringBuilder sr=new StringBuilder(s);
	if(a!=""&&b!="")
	{
		if(a.length()>b.length())
		{
			sr.append(a.charAt(a.length()-1));
			sr.append(b);
			System.out.println(sr);
		}
		else if(a.length()==b.length())
		{
			int m=a.compareToIgnoreCase(b);
			if(m>0)
			{
				sr.append(a.charAt(a.length()-1));
				sr.append(b);
			
			}
			else
			{
				sr.append(b.charAt(b.length()-1));
				sr.append(a);
					
			}
		}
		
	}
	
	
		String res=sr.toString();
		String toggled = ""; 
	    for(int i=0; i<res.length(); i++)
	    {

	        char letter = res.charAt(i); 

	        if(Character.isUpperCase(res.charAt(i)))
	        {
	             letter = Character.toLowerCase(letter); 
	             toggled = toggled + letter; 

	        }
	        else if(Character.isLowerCase(res.charAt(i)))
	        {
	            letter = Character.toUpperCase(letter);
	            toggled = toggled + letter; 
	        }

	    }
	    StringBuffer sr1=new StringBuffer(toggled);
	    if(c!=0)
		{
			String g=Integer.toString(c);
			char h=g.charAt(d-1);
			sr1.append(h);
			StringBuffer g1=new StringBuffer(g);
			g=g1.reverse().toString();
			char h1=g.charAt(d-1);
			sr1.append(h1);
		}
	    
	    String result=sr1.toString();
	return result;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(pass("Rajiv","Roy",560037,6));
System.out.println(pass("Manoj","Kumar",561327,2));
System.out.println(pass("Kumud","Kumar",561327,2));
	}

}
