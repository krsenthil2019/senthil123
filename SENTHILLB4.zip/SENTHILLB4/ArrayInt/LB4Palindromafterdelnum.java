package ArrayInt;

public class LB4Palindromafterdelnum {
public static  int poly(int a)
{
	int i,j,k=0,m=0;
	String v=Integer.toString(a);
	j=a;
	while(a>0){
		i=a%10;
		k=(k*10)+i;
		a=a/10;
	}
	
	if(k==j)
	{
		a=-1;
		
	}
	
	else
	{
		for(m=0;m<v.length();m++)
		{
			StringBuffer sb=new StringBuffer(v);
			String str=sb.deleteCharAt(m).toString();
			
			StringBuffer sb1=new StringBuffer(str);
			String str1=sb1.reverse().toString();
			
			if(str.equalsIgnoreCase(str1))
			{
				//System.out.println(v.charAt(m));
				a=Character.getNumericValue(v.charAt(m));
			}
		
	}}
	
	return a;	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(poly(12332));
System.out.println(poly(251532));
System.out.println(poly(10101));
	}

}
